<?php
 

use PrestaShop\PrestaShop\Core\Payment\PaymentOption;


class CashlessoRefundModuleFrontController extends ModuleFrontController
{
  public function initContent()
      {
      parent::initContent();
      $this->ajax = true;

       function __construct()
                 {
                   $this->controllers = array('refund');
                    parent::__construct();
                 }  
               }   

  public function displayAjaxRefund(){
  $ORDER_ID =$_REQUEST['order_id'];
  $AMOUNT = $_REQUEST['refund_amount'];
  $PG_REF_NUM = $_REQUEST['Pg_ref_number'];
  $TOTAL_PAID = $_REQUEST['total_paid'];
  $order_reference = $_REQUEST['order_reference'];
  
  $response = cashlesso::refund($ORDER_ID,$AMOUNT,$PG_REF_NUM,$TOTAL_PAID,$order_reference);
 if ($response == "success") {
   die(Tools::jsonEncode(array('result' => "Refund Successful")));
 }else{
  die(Tools::jsonEncode(array('result' => "Refund Fail")));
 }

}

}
?>
           
