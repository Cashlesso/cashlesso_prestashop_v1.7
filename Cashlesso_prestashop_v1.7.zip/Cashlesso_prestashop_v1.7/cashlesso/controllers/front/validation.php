<?php
/*
* 2007-2015 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2015 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

/**
 * @since 1.7.0
 */
class CashlessoValidationModuleFrontController extends ModuleFrontController
{
	public $warning = '';
	public $message = '';
	public function initContent()
  	{  
		parent::initContent();
	
		$this->context->smarty->assign(array(
		  	'warning' => $this->warning,
			'message' => $this->message
        	));        	
	    
		$this->setTemplate('module:cashlesso/views/templates/front/validation.tpl');  
    	
    	
  	}

   
    public function postProcess()
    {
        $cart = $this->context->cart;

        if ($cart->id_customer == 0 || $cart->id_address_delivery == 0 || $cart->id_address_invoice == 0 || !$this->module->active) {
            Tools::redirect('index.php?controller=order&step=1');
        }

        // Check that this payment option is still available in case the customer changed his address just before the end of the checkout process
        $authorized = false;
        foreach (Module::getPaymentModules() as $module) {
            if ($module['name'] == 'cashlesso') {
                $authorized = true;
                break;
            }
        }


        if (!$authorized) {
           $this->warning='This payment method is not available.';
		   $this->message='Contact Administrator for available payment methods.';
		   return;
        }

        $customer = new Customer($cart->id_customer);

        if (!Validate::isLoadedObject($customer)) {
            Tools::redirect('index.php?controller=order&step=1');
        }

		$currency = $this->context->currency;
		
	
			if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			//process Cashlesso response
			$responce_array = filter_input_array(INPUT_POST);
			foreach ($responce_array as $key => $value) {
                    if ($key == 'HASH') {
                        continue;
                    } else {
                        $responceParamsJoined[] = "$key=$value";
                    }
                }
            
            $Salt = Configuration::get('CASHLESSO_SALT');
            $responce_data_hash = $this->cashlesso_hash_responce_data($responceParamsJoined, $Salt);
			$postdata = $_REQUEST;	
			$cart_id = $cart->id;		
			
			if (isset($_REQUEST['HASH'])){
                    $HASH = $_REQUEST['HASH'];
                     
                }else{
                    $CUST_EMAIL = "NA";
                }
                if (isset($_REQUEST['RESPONSE_CODE'])){
                    $RESPONSE_CODE = $_REQUEST['RESPONSE_CODE'];
                     
                }else{
                    $RESPONSE_CODE = "NA";
                }
                if (isset($_REQUEST['STATUS'])){
                    $STATUS = $_REQUEST['STATUS'];
                     
                }else{
                    $STATUS = "NA";
                }
                if (isset($_REQUEST['AMOUNT'])){
                    $AMOUNT = $_REQUEST['AMOUNT']/100;
                     
                }else{
                    $AMOUNT = "NA";
                }
                if (isset($_REQUEST['PG_REF_NUM'])){
                    $PG_REF_NUM = $_REQUEST['PG_REF_NUM'];
                     
                }else{
                    $PG_REF_NUM = "NA";
                }
                if (isset($_REQUEST['ORDER_ID'])){
                    $ORDER_ID = $_REQUEST['ORDER_ID'];
                     
                }else{
                    $ORDER_ID = "NA";
                }

                $extraData = array(
                'transaction_id'    =>  $PG_REF_NUM,
            );
                
			if($responce_data_hash == $HASH && $RESPONSE_CODE == 000 && $STATUS == "Captured"){
				$status = Configuration::get('CASHLESSO_ID_ORDER_SUCCESS');
				$responseMsg = "Thank you for shopping with us. Your account has been charged and your transaction is successful. We will be shipping your order to you soon.";
				PrestaShopLogger::addLog("Cashlesso: Created Order for Cartid-".$cart_id,1, null, 'Cashlesso', (int)$cart_id, true);
			$this->module->validateOrder((int)$cart_id,  $status, (float)$AMOUNT, "Cashlesso(OrderId:".$ORDER_ID.")", $PG_REF_NUM, $extraData, null, false, $customer->secure_key);
			Tools::redirect('index.php?controller=order-confirmation&id_cart='.(int)$cart->id.'&id_module='.(int)$this->module->id.'&id_order='.$this->module->currentOrder.'&key='.$customer->secure_key);

			}else{
				$status = Configuration::get('CASHLESSO_ID_ORDER_FAILED');
				$responseMsg = "Thank you for shopping with us. Your transaction is not successful.";
				PrestaShopLogger::addLog("Cashlesso: Created Order for Cartid-".$cart_id,1, null, 'Cashlesso', (int)$cart_id, true);
			$this->module->validateOrder((int)$cart_id,  $status, (float)$AMOUNT, "Cashlesso(OrderId:".$ORDER_ID.")", $PG_REF_NUM, $extraData, null, false, $customer->secure_key);
			$this->warning= $responseMsg;
			} 
			
		}
		}
		
	public function cashlesso_hash_responce_data($array, $salt_key) 
    {
    sort($array);
    $merchant_data_string = implode('~', $array);
    $format_Data_string = $merchant_data_string . $salt_key;
    $hashData_uf = hash('sha256', $format_Data_string);
    $hashData = strtoupper($hashData_uf);
    return $hashData;
}

}

?>		
		
	