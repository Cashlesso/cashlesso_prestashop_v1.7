<?php /* Prestashop payment module for Cashlesso Payment Gateway */ ?>
<?php 	

error_reporting(E_ALL);	

use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

if (!defined('_PS_VERSION_')) {
	exit;
}

class cashlesso extends PaymentModule
{
	private $_html = '';
	private $_postErrors = array();
	private $_title;

	//require_once(dirname(__FILE__).'../../../../config/config.inc.php');
	//require_once(dirname(__FILE__).'../../../../init.php');

public function initContent()
      {
      parent::initContent();
      $this->ajax = true;
      require_once(dirname(__FILE__).'../../../../config/config.inc.php');
	require_once(dirname(__FILE__).'../../../../init.php');
      }

	
	function __construct()
	{		
		$this->name = 'cashlesso';		
		$this->tab = 'payments_gateways';		
		$this->version = 1.7;
		$this->author = 'Cashlesso.com';
		$this->bootstrap = true;			
		parent::__construct();		
			
		$this->displayName = $this->trans('Cashlesso Payment Gateway', array(), 'Modules.Cashlesso.Admin');
		$this->description = $this->trans('Accept payments by Cashlesso', array(), 'Modules.Cashlesso.Admin');
		$this->confirmUninstall = $this->trans('Are you sure you want to delete these details?', array(), 'Modules.Cashlesso.Admin');
		$this->ps_versions_compliancy = array('min' => '1.7.0.0', 'max' => _PS_VERSION_);

		$cashlesso_merchant_id= Configuration::get('CASHLESSO_MERCHANT_ID');
		$cashlesso_salt= Configuration::get('CASHLESSO_SALT');
		$cashlesso_mode= Configuration::get('CASHLESSO_MODE');
		$cashlesso_currency = Configuration::get('CASHLESSO_CURRENCY');
		
		
		$title = "Cashlesso";
						
		$this->_title = $title;
		
		$this->page = basename(__FILE__, '.php');		
					
	}	
	
	
	public function install()
	{
		Db::getInstance()->Execute('INSERT INTO `' . _DB_PREFIX_ . 'order_state` ( `invoice`, `send_email`, `color`, `unremovable`, `logable`, `delivery`, `module_name`)	VALUES	(0, 0, \'#33FF99\', 0, 1, 0, \'cashlesso\');');
		$id_order_state = (int) Db::getInstance()->Insert_ID();
		Db::getInstance()->Execute('INSERT INTO `' . _DB_PREFIX_ . 'order_state_lang` (`id_order_state`, `id_lang`, `name`, `template`) VALUES ('.$id_order_state.', 1, \'Payment accepted\', \'payment\')');
		Configuration::updateValue('CASHLESSO_ID_ORDER_SUCCESS', $id_order_state);			
		unset($id_order_state);
				
		Db::getInstance()->Execute('INSERT INTO `' . _DB_PREFIX_ . 'order_state`( `invoice`, `send_email`, `color`, `unremovable`, `logable`, `delivery`, `module_name`) VALUES (0, 0, \'#33FF99\', 0, 1, 0, \'cashlesso\');');
		$id_order_state = (int) Db::getInstance()->Insert_ID();
		Db::getInstance()->Execute('INSERT INTO `' . _DB_PREFIX_ . 'order_state_lang` (`id_order_state`, `id_lang`, `name`, `template`) VALUES ('.$id_order_state.', 1, \'Payment Failed\', \'payment\')');
		Configuration::updateValue('CASHLESSO_ID_ORDER_FAILED', $id_order_state);		
		unset($id_order_state);
		
		return parent::install()
			&& $this->registerHook('paymentOptions')
			 && $this->registerHook('displayAdminOrder');

			
	
	}

	public function uninstall()
	{
		
		Db::getInstance()->Execute('DELETE FROM `' . _DB_PREFIX_ . 'order_state_lang` WHERE id_order_state = '.Configuration::get('CASHLESSO_ID_ORDER_SUCCESS').' and id_lang = 1' );
		Db::getInstance()->Execute('DELETE FROM `' . _DB_PREFIX_ . 'order_state_lang`  WHERE id_order_state = '.Configuration::get('CASHLESSO_ID_ORDER_FAILED').' and id_lang = 1');

		return Configuration::deleteByName('CASHLESSO_MERCHANT_ID')
			&& Configuration::deleteByName('CASHLESSO_SALT')
			&& Configuration::deleteByName('CASHLESSO_MODE')
			&& Configuration::deleteByName('CASHLESSO_CURRENCY')
			&& parent::uninstall();		
	}

 
	public function hookPaymentOptions($params)
	{		
		if (!$this->active) {
			return;
		}
	
		$newOption = new PaymentOption();
		
		if ($this->_title == "Cashlesso")
		{
			
			$cashlesso_mode= Configuration::get('CASHLESSO_MODE');
			$action = 'https://www.cashlesso.com/pgui/jsp/paymentrequest';
			if($cashlesso_mode == 'sandbox')
			{
				$action = 'https://uat.cashlesso.com/pgui/jsp/paymentrequest';
			}
			
			$inputs = $this->cashlessoInput();
			
			$newOption->setCallToActionText($this->l($this->_title))			
				->setAction($action)
				->setInputs($inputs)
				->setAdditionalInformation($this->context->smarty->fetch('module:cashlesso/cashlesso.tpl'));
				
				//->setLogo(Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/logo.jpg'));				
			
			$newOption->setModuleName('cashlesso');
		}
		
		return [$newOption];
	}
	
	private function _postValidation()
	{
		if (Tools::isSubmit('btnSubmit')) {
			if (!Tools::getValue('CASHLESSO_MERCHANT_ID')) {
				$this->_postErrors[] = $this->trans('MerchantId  is required.', array(), 'Modules.Cashlesso.Admin');
			} elseif (!Tools::getValue('CASHLESSO_SALT')) {
				$this->_postErrors[] = $this->trans('Salt is required.', array(), 'Modules.Cashlesso.Admin');		
			}elseif (!Tools::getValue('CASHLESSO_CURRENCY')) {
				$this->_postErrors[] = $this->trans('Currency is required.', array(), 'Modules.Cashlesso.Admin');		
			}  				
		}
	}

	private function _postProcess()
	{
		if (Tools::isSubmit('btnSubmit')) {
			Configuration::updateValue('CASHLESSO_MERCHANT_ID', Tools::getValue('CASHLESSO_MERCHANT_ID'));
			Configuration::updateValue('CASHLESSO_SALT', Tools::getValue('CASHLESSO_SALT'));
			Configuration::updateValue('CASHLESSO_MODE', Tools::getValue('CASHLESSO_MODE'));
			Configuration::updateValue('CASHLESSO_CURRENCY', Tools::getValue('CASHLESSO_CURRENCY'));
			}
		$this->_html .= $this->displayConfirmation($this->trans('Settings updated', array(), 'Admin.Notifications.Success'));
	}
	
	public function getContent(){
		 $this->_html = '';

        if (Tools::isSubmit('btnSubmit')) {
            $this->_postValidation();
            if (!count($this->_postErrors)) {
                $this->_postProcess();
            } else {
                foreach ($this->_postErrors as $err) {
                    $this->_html .= $this->displayError($err);
                }
            }
        }

        $this->_html .= $this->_displayCheck();
        $this->_html .= $this->renderForm();

		return $this->_html;
	}
	
	public function renderForm()
	{
		
		$options = array(
			array(
					'id_option' => 'production', 
					'name' => 'production' 
					),
				array(
					'id_option' => 'sandbox',
					'name' => 'sandbox'
					),
				);
			
		$fields_form = array(
			'form' => array(
					'legend' => array(
						'title' => $this->trans('Cashlesso Gateway details', array(), 'Modules.Cashlesso.Admin'),
						'icon' => 'icon-envelope'
						),
					'input' => array(
						array(
							'type' => 'select',
							'label' => $this->trans('Gateway Mode', array(), 'Modules.Cashlesso.Admin'),
							'name' => 'CASHLESSO_MODE',
							'required' => true,
							'options' => array(
								'query' => $options,
								'id' => 'id_option', 
								'name' => 'name'
								)
							),
						 array(
							'type' => 'text',
							'label' => $this->trans('Merchant ID', array(), 'Modules.Cashlesso.Admin'),
							'name' => 'CASHLESSO_MERCHANT_ID',
							'required' => true
							),
						array(
							'type' => 'text',
							'label' => $this->trans('Salt', array(), 'Modules.Cashlesso.Admin'),
							'name' => 'CASHLESSO_SALT',
							'required' => true
							),
						array(
							'type' => 'text',
							'label' => $this->trans('Currency (Eg: INR,USD..)', array(), 'Modules.Cashlesso.Admin'),
							'name' => 'CASHLESSO_CURRENCY',
							'required' => true
							),
						),
					'submit' => array(
						'title' => $this->trans('Save', array(), 'Admin.Actions'),
						)
					),
				);

		$helper = new HelperForm();
		$helper->show_toolbar = false;
		$helper->id = (int)Tools::getValue('id_carrier');
		$helper->identifier = $this->identifier;
		$helper->submit_action = 'btnSubmit';
		$helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
		$helper->token = Tools::getAdminTokenLite('AdminModules');
		$helper->tpl_vars = array('fields_value' => $this->getConfigFieldsValues());

		$this->fields_form = array();

		return $helper->generateForm(array($fields_form));
	}

	public function getConfigFieldsValues(){
		return array(
			'CASHLESSO_MERCHANT_ID' => Tools::getValue('CASHLESSO_MERCHANT_ID', Configuration::get('CASHLESSO_MERCHANT_ID')),
			'CASHLESSO_SALT' => Tools::getValue('CASHLESSO_SALT', Configuration::get('CASHLESSO_SALT')),
			'CASHLESSO_MODE' => Tools::getValue('CASHLESSO_MODE', Configuration::get('CASHLESSO_MODE')),
			'CASHLESSO_CURRENCY' => Tools::getValue('CASHLESSO_CURRENCY', Configuration::get('CASHLESSO_CURRENCY')),
			 );
	}

	 
	
	private function _displayCheck()
	{
		return $this->display(__FILE__, './views/templates/hook/infos.tpl');
	}


	protected function cashlessoInput()
	{
		global $smarty, $cart;

		
		$customer = new Customer($cart->id_customer);
		$address = new Address($cart->id_address_invoice);
		$the_currency = Configuration::get('CASHLESSO_CURRENCY');
		$cashlesso_mode= Configuration::get('CASHLESSO_MODE');
		$SALT =  Configuration::get('CASHLESSO_SALT');

		
		 if ($the_currency == 'INR') {
                $the_currency = '356';
            } elseif ($the_currency == 'GBP') {
                $the_currency = '826';
            } elseif ($the_currency == 'USD') {
                $the_currency = '840';
            } elseif ($the_currency == 'EUR') {
                $the_currency = '978';
            } else {
                $the_currency = '356';
            }


		$PAY_ID = Configuration::get('CASHLESSO_MERCHANT_ID');
		$ORDER_ID = $cart->id;
		$AMOUNT = $cart->getOrderTotal()*100;
		$TXNTYPE = "SALE";
		$CUST_NAME = $address->firstname.'_'.$address->lastname;
		$CUST_STREET_ADDRESS1 = $address->address1;
		$CUST_ZIP = $address->postcode;
		$CUST_PHONE = $address->phone;
		$CUST_EMAIL = $customer->email;
		$CUST_ID = 'CUST_ID'.$cart->id.rand(200,3000);
		$PRODUCT_DESC = "Product Information";
		$CURRENCY_CODE = $the_currency;
		$RETURN_URL = $this->context->link->getModuleLink($this->name, 'validation', array(), true);
		
		$CUST_CITY = $address->city;
		$CUST_COUNTRY = $address->country;

		$values  = array(
			 
			'PAY_ID' => $PAY_ID,
			'ORDER_ID' => $ORDER_ID,
			'AMOUNT' => $AMOUNT,
			'TXNTYPE' => $TXNTYPE,
			'CUST_SHIP_CITY' => $CUST_CITY,
			'CUST_SHIP_COUNTRY'=> $CUST_COUNTRY,
			'CUST_SHIP_NAME' => $CUST_NAME,
			'CUST_SHIP_STREET_ADDRESS1' => $CUST_STREET_ADDRESS1,
			'CUST_SHIP_ZIP' => $CUST_ZIP,
			'CUST_SHIP_PHONE' => $CUST_PHONE,
			'CUST_EMAIL' => $CUST_EMAIL,
			'CUST_ID' => $CUST_ID,
			'PRODUCT_DESC' => $PRODUCT_DESC,
			'CURRENCY_CODE' => $CURRENCY_CODE,
			'RETURN_URL' => $RETURN_URL,
		);

		 foreach ($values as $key => $value) {

                        $requestParamsJoined[] = "$key=$value";
                    }

		$HASH = $this->generateHash($requestParamsJoined, $SALT);

		$values['HASH'] = $HASH;

		$inputs = array();
		foreach ($values as $k => $v)
		{
			$inputs[$k] = array(
				'name' => $k,
				'type' => 'hidden',
				'value' => $v,						
			);	
		}	
		
		return $inputs;

	}
	
	public function hookDisplayAdminOrder()
    { 
    	
    	$flag=0;
    	$TotalAmount = "";
    	$PaymentMethod = "";
    	$order_reference = "";
    	$AmountLabel = "Total Amount :";
    	$RefundAmountLabel = "Enter Refund Amount :";
    	$ConfirmationAlert = "Are you sure you want to refund the payment?";
    	$order_reference="";
    	
    	$link = new Link();
$url = $this->context->link->getModuleLink($this->name, 'refund?action=Refund', array(), true);
 	$token = Tools::getAdminTokenLite('AdminOrders');

    	 $id_order = Tools::getValue('id_order');
    	 $getOrder = 'SELECT * FROM `'._DB_PREFIX_.'orders`
			WHERE `id_order` = \''.pSQL($id_order).'\'';
    	 $order = Db::getInstance()->getRow($getOrder);

    	if ($order) {
    	$pg_order_id = $order['id_cart'];
    	$TotalAmt = $order['total_paid'];
    	$TotalAmount = number_format($TotalAmt, 2, '.', '');
    	$PaymentMethod = $order['module'];
    	$id_order_state = $order['current_state'];
    	$order_reference = $order['reference'];
		$StatusQuery = 'SELECT `name`
            FROM `'._DB_PREFIX_.'order_state_lang`
            WHERE `id_order_state` = \''.pSQL($id_order_state).'\'';
         
		$Status = Db::getInstance()->getRow($StatusQuery);
		
    	if($Status['name'] == 'Payment accepted'){
    		$flag = 1;
    		}else{
    	  	$flag = 0;
    	  }
    	}

    	 $getPgRefNumber = 'SELECT `transaction_id`
            FROM `'._DB_PREFIX_.'order_payment`
            WHERE `order_reference` = \''.pSQL($order_reference).'\'';
        $Pg_ref_number = Db::getInstance()->getRow($getPgRefNumber);

      
    	if($flag == 1 && $TotalAmount > 0 && $PaymentMethod == 'cashlesso' && $Pg_ref_number!= ""){

    		$this->context->smarty->assign(array(
                'orderId' => (int)$pg_order_id,
                'order' => $order,
                'TotalAmount' => $TotalAmount,
                'AmountLabel' => $AmountLabel,
                'RefundAmountLabel'=>$RefundAmountLabel,
                'ConfirmationAlert'=>$ConfirmationAlert,
                'Pg_ref_number'=>$Pg_ref_number,
                'token'=>$token,
                'url'=>$url,
                'order_reference'=>$order_reference
                
            ));
            return $this->display(__FILE__, 'views/templates/hook/displayAdminOrder.tpl');
    	}
    	return '';
} 

 
public function refund($order_id,$amount,$Pg_ref_number,$total_paid,$order_references){
	
	$Sandbox = Configuration::get('CASHLESSO_MODE');
	$Salt = Configuration::get('CASHLESSO_SALT');
	$PAY_ID = Configuration::get('CASHLESSO_MERCHANT_ID');
	$ORDER_ID = (int)$order_id;
	$AMOUNT = (double)$amount*100;
	$CURRENCY_CODE = "356";
	$TXNTYPE = "REFUND";
	$REFUND_ORDER_ID = "Order" . rand(10,9999);
	$PG_REF_NUM = $Pg_ref_number;
	$TOTAL_PAID = $total_paid;


    $total_amount = (double)$TOTAL_PAID*100;
	$leftAmount = $total_amount - $AMOUNT;
 	$finalAmount = (double)$leftAmount/100;

if($PG_REF_NUM != "" && $total_amount>0 && $total_amount>=$AMOUNT && $AMOUNT>0){
 		
 		$result = cashlesso::processRefund($Sandbox,$PAY_ID,$ORDER_ID,$AMOUNT,$TXNTYPE,$CURRENCY_CODE,$Salt,$PG_REF_NUM,$REFUND_ORDER_ID);
 		
 		if(isset($result['RESPONSE_CODE']) && $result['RESPONSE_CODE']==000 && isset($result['RESPONSE_CODE']) && $result['RESPONSE_MESSAGE'] == "SUCCESS"){
 			$status =  $result['RESPONSE_CODE'];
 			
 			$RefundedAmount = $result['TOTAL_AMOUNT'];
 			$covAmount = $RefundedAmount/100;
			$formatedAmount = number_format($covAmount, 2, '.', '');
			$negAmt = "-".$formatedAmount;

			//for update leftamount in db
			$updateOrderAmount ='UPDATE `'._DB_PREFIX_.'orders` SET `total_paid` = '.$finalAmount.' WHERE `'._DB_PREFIX_.'orders`.`id_cart` = '.$ORDER_ID.'';
    	 	Db::getInstance()->execute($updateOrderAmount);
    	 
$PG_REF_NUM = $result['PG_REF_NUM'];
$order_reference =	$order_references;
$id_currency =  $findRowForPaymentNotif['id_currency'];
$amount = "-".$formatedAmount;
$payment_method = "Cashlesso(Refund)";
$conversion_rate = $findRowForPaymentNotif['conversion_rate'];
$transaction_id = $PG_REF_NUM;
$date_add = date('Y-m-d H:i:s');

 
   $sql =  "INSERT INTO `" . _DB_PREFIX_ . "order_payment` SET `id_order_payment` = '', `order_reference` = '" . $order_reference. "', `id_currency` = '', `amount` = '".$amount."', `payment_method` = 'Cashlesso(Refund)', `conversion_rate` = '', `transaction_id` = '".$transaction_id."', `card_number` = '', `card_brand` = '', `card_expiration` = '', `card_holder` = '', `date_add` = '" . $date_add. "'";
 		Db::getInstance()->execute($sql);


			if($total_amount == $RefundedAmount){
				 $StatusCode = 7;
				 $updateRefundStatusToOrder = 'UPDATE `'._DB_PREFIX_.'orders` SET `current_state` = '.$StatusCode.' WHERE `'._DB_PREFIX_.'orders`.`id_cart` = '.$ORDER_ID.'';
				$updateStatus = Db::getInstance()->execute($updateRefundStatusToOrder);
				return success;
				 }
			return success;
 		}else{
 			return fail;
 		}
 	}else{
 		
 		if($total_amount==0){
				$StatusCode = 7;
				$updateRefundStatusToOrder = 'UPDATE `'._DB_PREFIX_.'orders` SET `current_state` = '.$StatusCode.' WHERE `'._DB_PREFIX_.'orders`.`id_cart` = '.$ORDER_ID.'';
				$updateStatus = Db::getInstance()->execute($updateRefundStatusToOrder);
				return fail;
			}else{
				return fail;
			}
 	 
 
}
}



public function processRefund($sandbox,$PAY_ID,$ORDER_ID,$AMOUNT,$TXNTYPE,$CURRENCY_CODE,$SALT,$PG_REF_NUM,$REFUND_ORDER_ID){	
	
$pg_ref = (int)$PG_REF_NUM;
 $data = array('PAY_ID' => $PAY_ID, 'ORDER_ID' => $ORDER_ID, 'AMOUNT' => $AMOUNT, 'TXNTYPE' => $TXNTYPE, 'CURRENCY_CODE' => $CURRENCY_CODE, 'PG_REF_NUM' => $pg_ref, 'REFUND_ORDER_ID' => $REFUND_ORDER_ID); 

foreach ($data as $key => $value) {
        $responceParamsJoined[] = "$key=$value";
}
	sort($responceParamsJoined);
    $merchant_data_string = implode('~', $responceParamsJoined);
    $format_Data_string = $merchant_data_string . $SALT;
    $hashData_uf = hash('sha256', $format_Data_string);
    $hashData = strtoupper($hashData_uf);
    $HASH = $hashData;
 

 $data["HASH"] = $HASH;

 if ($sandbox == true) {
                $url = "https://uat.cashlesso.com/pgws/transact";
            } else {
                $url = "https://www.cashlesso.com/pgws/transact";
            }


 $postvars =  json_encode($data); 
   
 $cURL = curl_init();

curl_setopt($cURL, CURLOPT_URL,$url);
curl_setopt($cURL, CURLOPT_POST, 1);
curl_setopt($cURL, CURLOPT_POSTFIELDS,$postvars);
curl_setopt($cURL, CURLOPT_RETURNTRANSFER, true);
curl_setopt($cURL, CURLOPT_HTTPHEADER, array(                                                                          
    'Content-Type: application/json',                                                                                
    'Content-Length: ' . strlen($postvars))                                                                       
);

$server_output = curl_exec($cURL);
$refundArray = json_decode($server_output, true);
curl_close ($cURL);
return $refundArray;

}

public function generateHash($array, $salt_key) {
	sort($array);
    $merchant_data_string = implode('~', $array);
    $format_Data_string = $merchant_data_string . $salt_key;
    $hashData_uf = hash('sha256', $format_Data_string);
    $hashData = strtoupper($hashData_uf);
    return $hashData;
}
	
	
}
?>